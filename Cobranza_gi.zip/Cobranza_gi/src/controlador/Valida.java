/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

//import cliente.Cliente;
import controlador.Procedimiento;
import entidad.Filtro;
//import entidad.Deuda;
//import entidad.Producto;
//import entidad.Vendedor;
import java.awt.Cursor;
import java.awt.Frame;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTextPane;
//import lugar.Departamento;
//import lugar.Distrito;
//import lugar.Provincia;
//import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;
//import proveedor.Proveedor;
//import vista.Carga1;
//import vista.Menu;
//import vista_cliente.AItem;
//import vista_proveedor.AItemc;

/**
 *
 * @author LAPTOP1
 */
public class Valida {
//     public static void SoloNum(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                int k=(int)evt.getKeyChar();
//                if(k>=46 && k<=57){
//                    if(k==46){
//                        String dato=a.getText();
//                        int tama=dato.length();
//                        for(int i=0;i<=tama;i++){
//                            if(dato.contains("."))
//                                evt.setKeyChar((char)KeyEvent.VK_CLEAR);
//                        }
//                    }if(k==47){
//                        evt.setKeyChar((char)KeyEvent.VK_CLEAR);
//                    }
//        
//                }else{
//                    evt.setKeyChar((char)KeyEvent.VK_CLEAR);
//                    evt.consume();
//                }
//            }
//        
//        });
//    }
//    
//    public static void Num(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                               
//                    char cara = evt.getKeyChar();
//                    if( !Character.isDigit(cara)){
//                    evt.consume();
//                    }
//                
//            }        
//        });
//    }
//    
//    public static void Ruc_Cli(final JComboBox a){
//        ArrayList<Cliente> listv;
//        Procedimiento Obj=new Procedimiento();
//        listv=Obj.Listar_Cliente();
//        a.addItem("SELECCIONE");
//        for (Cliente Objpro : listv) {
//            a.addItem(Objpro.getRuc());
//        } 
//        AutoCompleteDecorator.decorate(a); 
//    }
//    
//    public static void Ruc_Cli_Deudores(final JComboBox a){
//        ArrayList<Deuda> lisf;
//        Procedimiento Obj=new Procedimiento();
//        lisf=Obj.Listar_Cli_Deuda();
//        a.addItem("SELECCIONE");
//        for (Deuda Objpro : lisf) {
//            a.addItem(Objpro.getRuc());
//        } 
//        AutoCompleteDecorator.decorate(a); 
//    }
//    
//    public static void Ruc_Pro(final JComboBox a){
//        ArrayList<Proveedor> listv;
//        Procedimiento Obj=new Procedimiento();
//        listv=Obj.Listar_Proveedor();
//        a.addItem("SELECCIONE");
//        for (Proveedor Objpro : listv) {
//            a.addItem(Objpro.getRuc());
//        } 
//        AutoCompleteDecorator.decorate(a); 
//    }
//    
//    public static void Dni(final JComboBox a){
//        ArrayList<Vendedor> listv;
//        Procedimiento Obj=new Procedimiento();
//        listv=Obj.Listar_Vendedor();
//        a.addItem("SELECCIONE");
//        for (Vendedor Objpro : listv) {
//            a.addItem(Objpro.getDni());
//        } 
//        AutoCompleteDecorator.decorate(a); 
//    }
    
    public static int[] Campana(final JComboBox a){
        ArrayList<Filtro> lcamp;
        Procedimiento Obj=new Procedimiento();
        lcamp=Obj.Listar_Campana();  
        a.removeAllItems();
        int aux=0,A[];
        A= new int[lcamp.size()];
        //System.out.println("Longitud "+lcamp.size()+"----- \n");
//        a.addItem("SELECCIONE");
//        A[0]=0;
        for(Filtro Objdep:lcamp){ 
            a.addItem(Objdep.getNombre());
            
            A[aux]=Objdep.getId();
            
            //System.out.println("Campaña "+aux+".- "+A[aux]+"--------"+Objdep.getId()+"----- \n");     
            aux++;
        }       
        a.setSelectedIndex(0);
        
        return A;
    }
    
    public static int[] Estrategia(final JComboBox a,int b){
        
        Procedimiento Obj=new Procedimiento();
                System.out.println("campaña "+b+"----- \n");
                ArrayList<Filtro> lestr;
                lestr=Obj.Listar_Filtro(b);  
                a.removeAllItems();
                int aux=0,A[];
                A= new int[lestr.size()+1];
                
                 System.out.println("Longitud filtro "+lestr.size()+"----- \n");
//                a.addItem("SELECCIONE");
//                A[aux]=0;
                for(Filtro Objdep:lestr){ 
                    a.addItem(Objdep.getNombre());
                    
                    A[aux]=Objdep.getId(); 
                    System.out.println("Filtro "+aux+".- "+A[aux]+"--------"+Objdep.getId()+"----- \n");
                    aux++;
                    
                    
                }  
                a.setSelectedIndex(0);
        return A;
    }
    
//    public static int Dist(final JComboBox a,String b){
//        
//        Procedimiento Obj=new Procedimiento();
//        Provincia Objen=Obj.Buscar_ProvxNom(b);
//                    int c=Objen.getId_prov();
//                    ArrayList<Distrito> lisdist;
//                    lisdist=Obj.Listar_DistxProv(Objen.getId_prov());  
//                    a.removeAllItems();
//                    a.addItem("SELECCIONE");
//                    for(Distrito Objdep:lisdist){ 
//                            a.addItem(Objdep.getDist());
//                    }  
//                    a.setSelectedIndex(0);
//        return c;
//    }
//    
//   
//    public static void ValiRuc(JTextField a,JTextField rsoc,JTextField dir,JComboBox dep,JComboBox prov,JComboBox dist,final JButton b,final JButton c
//                                ){
//        
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            @SuppressWarnings("WaitWhileNotSynced")
//            public void keyPressed(KeyEvent e){                
//                if(a.getText().trim().length()==11){
//                    if(e.getKeyCode()==KeyEvent.VK_ENTER){
//
//                        Consulta Cons=new Consulta();
//                        Cons.consultar(a);
//                        Cons.mostrar(rsoc,dep,prov,dist,dir);
//                        c.setEnabled(true);
//
//                    }
//                }
//            }
//            
//            @Override
//            public void keyTyped(KeyEvent evt){                    
//                char cara = evt.getKeyChar();
//                String car=a.getText();
////                String car1=a.getText()+String.valueOf(cara); 
//                int l=car.length();
//                
////                System.out.println("long:"+l+"/char : "+cara+"/txt : "+a.getText()+"/sum : "+car1+"\n");
////              Character.isLetter(cara) ||               
//             
//            if(cara!=(char)KeyEvent.VK_ENTER){
//                if( Character.isDigit(cara)){                  
//                    b.setEnabled(true); 
//                    if(l>=0 && l<=10){                      
//                        if(l==7 || l==10){
//                            c.setEnabled(true);
//                        }else{                            
//                            c.setEnabled(false);
//                        }                  
//                    }else{
//                        evt.setKeyChar((char)KeyEvent.VK_CLEAR);
//                    } 
//                }else{ 
////                        System.out.println("borrar \n");                        
//                    if( l!=7 || l!=10){
//                        if(l==0){
//                        b.setEnabled(false);                            
//                        }
//                        c.setEnabled(false);
//                    }
//                    
//                    if(l==8){                        
//                        c.setEnabled(true);
//                    }
//                    evt.consume();
//                    evt.setKeyChar((char)KeyEvent.VK_CLEAR);
////                  getToolkit().beep();
//                }
//            }  
//            }
//                   
//        });
//    }
//    
//    public static void ValiDni(JTextField a,
////            ,JTextField rsoc,JTextField dir,JComboBox dep,JComboBox prov,JComboBox dist,
//            final JButton b,
//            final JButton c
//        ){
//        
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyPressed(KeyEvent e){                
//                if(a.getText().trim().length()==7){
//                    if(e.getKeyCode()==KeyEvent.VK_ENTER){
////                        Consulta Cons=new Consulta();
////                        Cons.consultar(a);
////                        Cons.mostrar(rsoc,dep,prov,dist,dir);
////                        c.setEnabled(true);
//                    }
//                }
//            }
//            
//            @Override
//            public void keyTyped(KeyEvent evt){                    
//                char cara = evt.getKeyChar();
//                String car=a.getText();
//                int l=car.length();            
//             
//            if(cara!=(char)KeyEvent.VK_ENTER){
//                if( Character.isDigit(cara)){                  
//                    b.setEnabled(true); 
//                    if(l>=0 && l<=7){                      
//                        if(l==7 ){
//                            c.setEnabled(true);
//                        }else{                            
//                            c.setEnabled(false);
//                        }                  
//                    }else{
//                        evt.setKeyChar((char)KeyEvent.VK_CLEAR);
//                    } 
//                }else{                      
//                    if( l!=8){
//                        if(l==0){
//                        b.setEnabled(false);                            
//                        }
//                        c.setEnabled(false);
//                    }
//                    
//                    evt.consume();
//                    evt.setKeyChar((char)KeyEvent.VK_CLEAR);
////                  getToolkit().beep();
//                }
//            }  
//            }
//                   
//        });
//    }
//    
//    
//    public static void Valitel(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String car=a.getText();
//                if(car.length()>6){
//                    evt.consume();
//                }else{
//                    char cara = evt.getKeyChar();
//                    if( !Character.isDigit(cara)){
//                    evt.consume();
//                    }
//                } 
//            }        
//        });
//    }
//    
//    public static void Valicel(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String car=a.getText();
//                if(car.length()>8){
//                    evt.consume();
//                }else{
//                    char cara = evt.getKeyChar();
//                    if( !Character.isDigit(cara)){
//                    evt.consume();
//                    }
//                } 
//            }        
//        });
//    }
//    
//    public static void Valianx(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String car=a.getText();
//                if(car.length()>3){
//                    evt.consume();
//                } 
//            }        
//        });
//    }
//    
//    public static void Valicor(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String car=a.getText();
//                if(car.length()>99){
//                    evt.consume();
//                } 
//            }        
//        });
//    }
//    
//    public static void Valirsoc(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String cor=a.getText();
//                if(cor.length()>149){
//                    evt.consume();
//                }else{
//                    char carac=evt.getKeyChar();
//                    if(Character.isLowerCase(carac)){
//                        String cad=(""+carac).toUpperCase();
//                        carac=cad.charAt(0);
//                        evt.setKeyChar(carac);
//                    }
//                } 
//            }        
//        });
//    }
//    
//    public static void Valimarca(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String cor=a.getText();
//                if(cor.length()>39){
//                    evt.consume();
//                }else{
//                    char carac=evt.getKeyChar();
//                    if(Character.isLowerCase(carac)){
//                        String cad=(""+carac).toUpperCase();
//                        carac=cad.charAt(0);
//                        evt.setKeyChar(carac);
//                    }
//                } 
//            }        
//        });
//    }
//    
//    public static void Valicod(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String cor=a.getText();
//                if(cor.length()>6){
//                    evt.consume();
//                }else{
//                    char carac=evt.getKeyChar();
//                    if(Character.isLowerCase(carac)){
//                        String cad=(""+carac).toUpperCase();
//                        carac=cad.charAt(0);
//                        evt.setKeyChar(carac);
//                    }
//                } 
//            }        
//        });
//    }
//    
//   public static void Validir(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String cor=a.getText();
//                if(cor.length()>249){
//                    evt.consume();
//                }else{
//                    char carac=evt.getKeyChar();
//                    if(Character.isLowerCase(carac)){
//                        String cad=(""+carac).toUpperCase();
//                        carac=cad.charAt(0);
//                        evt.setKeyChar(carac);
//                    }
//                } 
//            }        
//        });
//    }
//   
//   public static void Valicont(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String cor=a.getText();
//                if(cor.length()>49){
//                    evt.consume();
//                }else{
//                    char carac=evt.getKeyChar();
//                    if(Character.isLowerCase(carac)){
//                        String cad=(""+carac).toUpperCase();
//                        carac=cad.charAt(0);
//                        evt.setKeyChar(carac);
//                    }
//                } 
//            }        
//        });
//    }
//   
//   public static void Validar(final JTextField a,final JButton b){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String cara= a.getText();
//       
//                if(cara.length()>9){
//                    evt.consume();
//                }else{
//                    if(!"".equals(cara)){
//                        b.setEnabled(true);
//                    }else{
//                        b.setEnabled(false);
//                    }
//                } 
//            }        
//        });
//    }
//   
//   
//   public static void ValiUser(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String cor=a.getText();
//                if(cor.length()>9){
//                    evt.consume();
//                }else{
//                    char carac=evt.getKeyChar();
//                    if(Character.isLowerCase(carac)){
//                        String cad=(""+carac).toUpperCase();
//                        carac=cad.charAt(0);
//                        evt.setKeyChar(carac);
//                    }
//                } 
//            }        
//        });
//    }
//   
//   public static void ValiPass(final JPasswordField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String car=String.valueOf(a.getPassword());
//                if(car.length()>9){
//                    evt.consume();
//                } 
//            }        
//        });
//    }
//   
//   public static void ValiNom(final JTextField a){
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyTyped(KeyEvent evt){
//                String cor=a.getText();
//                if(cor.length()>39){
//                    evt.consume();
//                }else{
//                    char carac=evt.getKeyChar();
//                    if(Character.isLowerCase(carac)){
//                        String cad=(""+carac).toUpperCase();
//                        carac=cad.charAt(0);
//                        evt.setKeyChar(carac);
//                    }
//                } 
//            }        
//        });
//    }
//   
//   public static void BusPro(JTextField a,JTextPane b,JTextField c,final JButton d
//        ){
//        
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyPressed(KeyEvent e){                
//                if(a.getText().trim().length()==6){
//                    if(e.getKeyCode()==KeyEvent.VK_ENTER){
//                        Procedimiento Obj=new Procedimiento();
//                        Producto Objp;
//                        Objp=Obj.Buscar_Producto(a.getText().trim());
//                        if(Objp!=null){
//                           b.setText(Objp.getDet()+" "+Objp.getMar());
//                            c.setText(String.valueOf(Objp.getPuv()));
//                            AItem.stock=String.valueOf(Objp.getStk());
//                            AItem.precio=String.valueOf(Objp.getPuv());
//                            d.setEnabled(true);
//                        }else{
//                            JOptionPane.showMessageDialog(null, "PRODUCTO NO ENCONTRADO", "ALERTA", JOptionPane.INFORMATION_MESSAGE);
//                        }
//                    }
//                }
//            }
//        });
//    }
//   
//    public static void BusProC(JTextField a,JTextPane b,JTextField c,final JButton d
//        ){
//        
//        a.addKeyListener(new KeyAdapter(){
//            @Override
//            public void keyPressed(KeyEvent e){                
//                if(a.getText().trim().length()==6){
//                    if(e.getKeyCode()==KeyEvent.VK_ENTER){
//                        Procedimiento Obj=new Procedimiento();
//                        Producto Objp;
//                        Objp=Obj.Buscar_Producto(a.getText().trim());
//                        if(Objp!=null){
//                           b.setText(Objp.getDet()+" "+Objp.getMar());
//                            c.setText(String.valueOf(Objp.getPuc()));
//                            AItemc.stock=String.valueOf(Objp.getStk());
//                            AItemc.precio=String.valueOf(Objp.getPuc());
//                            d.setEnabled(true);
//                        }else{
//                            JOptionPane.showMessageDialog(null, "PRODUCTO NO ENCONTRADO", "ALERTA", JOptionPane.INFORMATION_MESSAGE);
//                        }
//                    }
//                }
//            }
//        });
//    }
   
}
