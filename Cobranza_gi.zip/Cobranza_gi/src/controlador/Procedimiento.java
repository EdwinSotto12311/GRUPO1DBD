
package controlador;

//import externo.ConsultaP;
//import cliente.*;
//import proveedor.*;
//import lugar.*;
//import entidad.*;
//import java.sql.*;
//import java.util.ArrayList;
import entidad.Filtro;
import entidad.Gestion;
import entidad.Usuario;
import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author LAPTOP1
 */
public class Procedimiento {
    private ResultSet rs;
    private PreparedStatement cs;
    
    public Usuario Login(String user,String pass){
        Usuario Obj = null;
        Conexionbd conec = new Conexionbd();
        rs = null;
        cs = null;
        try {
                cs = conec.getConexionbd().prepareStatement(" select * from usuario where usr=? and pass=?");
                cs.setString(1, user);
                cs.setString(2, pass);
                rs = cs.executeQuery();
                if(rs.next()){
//                    System.out.println("Usuario Encontrado \n");
                    Obj = new Usuario(
                            rs.getInt("id"),
                            rs.getString("usr"),
                            rs.getString("pass"));
                }
        }catch(SQLException ex){
            System.out.println(ex.getMessage()+"  3");
        }catch(Exception ex){
            System.out.println(ex.getMessage()+"  4");
        }finally{
            try{
                cs.close();
                rs.close();
                conec.desconectar();
            }catch(SQLException ex){}
        }        
        return Obj;
    }
    
    public void Registrar_entidad(String nombre,String ruc, String t_entidad, String telefono){
        
        Conexionbd conec = new Conexionbd();
        rs = null;
        cs = null;
        try {
                cs = conec.getConexionbd().prepareStatement(" insert into entidad_financiera "
                        + "(nombre, ruc, tipo_entidad, telefono_contacto, id_entfinan) "
                        + "values ('"+nombre+"', '"+ruc+"', '"+t_entidad+"', '"+telefono+"', nextval('seq_entidad_id'))");
                //rs = cs.executeQuery();
                cs.execute();
                System.out.println("El registro se realizo correctamente");
        }catch(SQLException ex){
            System.out.println(ex.getMessage()+"  3");
        }catch(Exception ex){
            System.out.println(ex.getMessage()+"  4");
        }finally{
            try{
                cs.close();
                //rs.close();
                conec.desconectar();
            }catch(SQLException ex){}
        }        
        
    }
    
    public Gestion Listar(int campana,int filtro){
        Gestion Obj = null;
        Conexionbd conec = new Conexionbd();
        rs = null;
        cs = null;
        try {
                cs = conec.getConexionbd().prepareStatement("SELECT  D.id_deudor,D.Nombres,D.ApellPat,D.ApellMat, De.monto_total, De.monto_capital, " +
"De.monto_total*(1-C.descuento/100) AS monto_descuento, De.origen, AGE(De.fecha_venc) as tiempo, C.descuento " +
"FROM Deudor D  " +
"inner join Deuda De " +
"on D.id_deudor = De.id_deudor  " +
"inner join campaña_deuda C " +
"on De.id_deuda = C.id_deuda " +
"Where D.id_deudor in (Select   ed.id_deudor from estrategia_deudor ed where ed.id_estrategia = "+filtro+" and ed.estado) " +
"and C.id_campaña= "+campana+"  ORDER BY C.descuento DESC LIMIT 1; ");
                
                rs = cs.executeQuery();
                if(rs.next()){
//                    System.out.println("Usuario Encontrado \n");
                    Obj = new Gestion(
                            rs.getInt("id_deudor"),
                            rs.getString("nombres"),
                            rs.getString("apellpat"),
                            rs.getString("apellmat"),
                            rs.getDouble("monto_total"),
                            rs.getDouble("monto_capital"),
                            rs.getDouble("monto_descuento"),
                            rs.getString("origen"),
                            rs.getString("tiempo"),
                            rs.getString("descuento")
                    
                    );
                }
        }catch(SQLException ex){
            System.out.println(ex.getMessage()+"  3");
        }catch(Exception ex){
            System.out.println(ex.getMessage()+"  4");
        }finally{
            try{
                cs.close();
                rs.close();
                conec.desconectar();
            }catch(SQLException ex){}
        }        
        return Obj;
    }
    
    public ResultSet ListarTelefono(int id_deudor){
       // Gestion Obj = null;
        Conexionbd conec = new Conexionbd();
        rs = null;
        cs = null;
        try {
                cs = conec.getConexionbd().prepareStatement("SELECT numero, mej_est_con, estado " +
                                                            "FROM Teléfono WHERE id_deudor = "+id_deudor);
                
                rs = cs.executeQuery();
                
                if(rs!=null){
                    System.out.println("Telefonos No Nulos \n");
                }else{
                    System.out.println("Telefonos Nulos \n");
                }
                
                //if(rs.next()){
//                    System.out.println("Usuario Encontrado \n");
//                    Obj = new Gestion(
//                            rs.getInt("id_deudor"),
//                            rs.getString("nombres"),
//                            rs.getString("apellpat"),
//                            rs.getString("apellmat"),
//                            rs.getDouble("monto_total"),
//                            rs.getDouble("monto_capital"),
//                            rs.getDouble("monto_descuento"),
//                            rs.getString("origen"),
//                            rs.getString("tiempo"),
//                            rs.getString("descuento")
//                    
//                    );

                
        }catch(SQLException ex){
            System.out.println(ex.getMessage()+"  3");
        }catch(Exception ex){
            System.out.println(ex.getMessage()+"  4");
        }finally{
            try{
                cs.close();
                
                //rs.close();
                conec.desconectar();
            }catch(SQLException ex){}
        }        
        return rs;
    }
    
    public ArrayList<Filtro> Listar_Campana(){
        ArrayList<Filtro> list = new ArrayList<>();
        Conexionbd conec = new Conexionbd();
        rs = null;
        cs = null;
        try{
            //System.out.println(" antes de sql------------- \n");
            cs = conec.getConexionbd().prepareStatement(" select cd.id_campaña,c.nombre,count(ed.id_estrategia) as contar,c.estado  " +
"from campaña_deuda cd  " +
"inner join campaña c " +
"on c.id_campaña = cd.id_campaña " +
"inner join deuda d " +
"on d.id_deuda= cd.id_deuda " +
"inner join deudor dr " +
"on dr.id_deudor=d.id_deudor " +
"inner join estrategia_deudor ed " +
"on ed.id_deudor=dr.id_deudor " +
"inner join estrategia e " +
"on e.id_estrategia=ed.id_estrategia " +
"WHERE c.estado and ed.estado and e.estado " +
"group by cd.id_campaña,c.nombre, c.estado order by count(ed.id_estrategia)");
            rs = cs.executeQuery();
            
            while(rs.next()){
                Filtro Obj = new Filtro(
                            rs.getInt("id_campaña"),
                            rs.getString("nombre"),
                            rs.getInt("contar"),
                            rs.getBoolean("estado")
                    );
                
                list.add(Obj);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage()+"  3");
        }catch(Exception ex){
            System.out.println(ex.getMessage()+"  4");
        }finally{
            try{
                cs.close();
                //rs.close();
                conec.desconectar();
            }catch(SQLException ex){}
        }
        return list;
    }
    
    public ArrayList<Filtro> Listar_Filtro(int aux){
        ArrayList<Filtro> lfiltro = new ArrayList<>();
        Conexionbd conec = new Conexionbd();
        rs = null;
        cs = null;
        try{
            System.out.println(aux+"antes de sql ------------- \n");
            cs = conec.getConexionbd().prepareStatement("select e.id_estrategia,e.nombre_estrategia, count(ed.id_deudor) as contar, e.estado " +
                "from estrategia e " +
                "inner join estrategia_deudor ed " +
                "on e.id_estrategia =ed.id_estrategia " +
                "where e.estado and ed.id_deudor in " +
                "(	select id_deudor from deuda where id_deuda in( " +
                "	select cd.id_deuda " +
                "	from campaña_deuda cd " +
                "	inner join campaña c " +
                "	on c.id_campaña = cd.id_campaña " +
                "	WHERE c.estado and c.id_campaña = "+aux+" )" +
                ") group by e.id_estrategia,e.nombre_estrategia " +
                "order by e.id_estrategia ");            
            //cs.setInt(1, aux);
            int x=0;
            rs = cs.executeQuery();
            //System.out.println(rs.next()+"------------- \n");
            //System.out.println(x+"------------- \n");
            while(rs.next()){
                x++;
                System.out.println(x+"------------- \n");
                Filtro Obj = new Filtro(
                            rs.getInt("id_estrategia"),
                            rs.getString("nombre_estrategia"),
                            rs.getInt("contar"),
                            rs.getBoolean("estado")
                    );
                lfiltro.add(Obj);
                
            }
            
        }catch(SQLException ex){
            System.out.println(ex.getMessage()+"  3");
        }catch(Exception ex){
            System.out.println(ex.getMessage()+"  4");
        }finally{
            try{
                cs.close();
                rs.close();
                conec.desconectar();
            }catch(SQLException ex){}
        }
        return lfiltro;
    }
}
