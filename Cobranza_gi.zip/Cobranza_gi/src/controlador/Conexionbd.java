
package controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author LAPTOP1
 */
public class Conexionbd {
    private String BD ="Cobranza";
    private String URL ="jdbc:postgresql://localhost:5432/"+BD;
    private String User = "postgres";
    private String Clave ="root";
    Connection connection = null;
    
    public Conexionbd(){
        try{
        Class.forName("org.postgresql.Driver");
        connection = DriverManager.getConnection(URL,User,Clave);
        if (connection!=null){
            System.out.println("Conexión a base de datos "+BD+" OK\n");
        }
        }catch(ClassNotFoundException | SQLException ex){
            System.out.println(ex.getMessage()+"  1");
        }
    }
    
    public Connection getConexionbd(){
        return connection;
    }

    public void desconectar(){
        try{
            System.out.println("Cerrando conexion");
            connection.close();
            
        }catch(SQLException ex){
            System.out.println(ex.getMessage()+"  2");
        }
    }
}
