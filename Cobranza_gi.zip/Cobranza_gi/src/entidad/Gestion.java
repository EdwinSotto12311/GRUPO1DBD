/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;

/**
 *
 * @author LAPTOP1
 */
public class Gestion {
    private int id;
    private String nombres;
    private String apellpat;
    private String apellmat;
    private Double monto_total;
    private Double monto_capital;
    private Double monto_descuento;
    private String origen;
    private String tiempo;
    private String descuento;

    public Gestion() {
    }
    
    public Gestion( int id,String nombres, String apellpat, String apellmat, Double monto_total, Double monto_capital,
                    Double monto_descuento, String origen, String tiempo, String descuento) {
        this.id=id;
        this.nombres =nombres;
        this.apellpat = apellpat;
        this.apellmat = apellmat;
        this.monto_total =monto_total;
        this.monto_capital = monto_capital;
        this.monto_descuento = monto_descuento;
        this.origen =origen;
        this.tiempo = tiempo;
        this.descuento = descuento;
    }

   

    /**
     * @return the nombres
     */
    public String getNombres() {
        return nombres;
    }

    /**
     * @param nombres the nombres to set
     */
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

     /* @return the id
     */
    public int getId() {
        return id;
    }

   
    public void setId(int id) {
        this.id = id;
    }
    /**
     * @return the apellpat
     */
    public String getApellpat() {
        return apellpat;
    }

    /**
     * @param apellpat the apellpat to set
     */
    public void setApellpat(String apellpat) {
        this.apellpat = apellpat;
    }

    /**
     * @return the apellmat
     */
    public String getApellmat() {
        return apellmat;
    }

    /**
     * @param apellmat the apellmat to set
     */
    public void setApellmat(String apellmat) {
        this.apellmat = apellmat;
    }

    /**
     * @return the monto_total
     */
    public Double getMonto_total() {
        return monto_total;
    }

    /**
     * @param monto_total the monto_total to set
     */
    public void setMonto_total(Double monto_total) {
        this.monto_total = monto_total;
    }

    /**
     * @return the monto_capital
     */
    public Double getMonto_capital() {
        return monto_capital;
    }

    /**
     * @param monto_capital the monto_capital to set
     */
    public void setMonto_capital(Double monto_capital) {
        this.monto_capital = monto_capital;
    }

    /**
     * @return the monto_descuento
     */
    public Double getMonto_descuento() {
        return monto_descuento;
    }

    /**
     * @param monto_descuento the monto_descuento to set
     */
    public void setMonto_descuento(Double monto_descuento) {
        this.monto_descuento = monto_descuento;
    }

    /**
     * @return the origen
     */
    public String getOrigen() {
        return origen;
    }

    /**
     * @param origen the origen to set
     */
    public void setOrigen(String origen) {
        this.origen = origen;
    }

    /**
     * @return the tiempo
     */
    public String getTiempo() {
        return tiempo;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(String tiempo) {
        this.tiempo = tiempo;
    }

    /**
     * @return the descuento
     */
    public String getDescuento() {
        return descuento;
    }

    /**
     * @param descuento the descuento to set
     */
    public void setDescuento(String descuento) {
        this.descuento = descuento;
    }

    
    
    
}
